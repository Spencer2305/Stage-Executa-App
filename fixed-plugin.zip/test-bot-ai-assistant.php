<?php
/**
 * Plugin Name: test bot AI Assistant
 * Description: AI chat widget for your WordPress site. Powered by Executa.ai
 * Version: 1.0.0
 * Author: Executa.ai
 * Author URI: https://executa.ai
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ExecutaAIWidget {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'render_widget'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'settings_init'));
    }
    
    public function enqueue_scripts() {
        if (!get_option('executa_ai_enabled', true)) {
            return;
        }
        
        wp_enqueue_script(
            'executa-ai-widget',
            plugin_dir_url(__FILE__) . 'assets/executa-widget.js',
            array(),
            '1.0.0',
            true
        );
        
        wp_enqueue_style(
            'executa-ai-widget',
            plugin_dir_url(__FILE__) . 'assets/executa-widget.css',
            array(),
            '1.0.0'
        );
        
        // Pass configuration to JavaScript
        wp_localize_script('executa-ai-widget', 'EXECUTA_AI_CONFIG', array(
            'apiUrl' => 'https://app.executa.ai',
            'assistantId' => 'cmc9idygx000gy93fouse1fn7',
            'bubbleColor' => '#000000',
            'assistantBubbleColor' => '#F3F4F6',
            'userBubbleColor' => '#3B82F6',
            'chatTitle' => 'AI Assistant',
            'welcomeMessage' => 'Hello! How can I help you today?',
            'enabled' => get_option('executa_ai_enabled', true)
        ));
    }
    
    public function render_widget() {
        if (!get_option('executa_ai_enabled', true)) {
            return;
        }
        
        echo '<div id="executa-ai-chat-widget"></div>';
    }
    
    public function add_admin_menu() {
        add_options_page(
            'test bot AI Settings',
            'test bot AI',
            'manage_options',
            'executa-ai-settings',
            array($this, 'settings_page')
        );
    }
    
    public function settings_init() {
        register_setting('executa_ai_settings', 'executa_ai_enabled');
        
        add_settings_section(
            'executa_ai_section',
            'Widget Settings',
            null,
            'executa_ai_settings'
        );
        
        add_settings_field(
            'executa_ai_enabled',
            'Enable AI Widget',
            array($this, 'enabled_field_render'),
            'executa_ai_settings',
            'executa_ai_section'
        );
    }
    
    public function enabled_field_render() {
        $enabled = get_option('executa_ai_enabled', true);
        echo '<input type="checkbox" name="executa_ai_enabled" value="1" ' . checked(1, $enabled, false) . '>';
        echo '<p class="description">Check to enable the AI chat widget on your website.</p>';
    }
    
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html('test bot'); ?> AI Settings</h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('executa_ai_settings');
                do_settings_sections('executa_ai_settings');
                submit_button();
                ?>
            </form>
            
            <div style="margin-top: 30px; padding: 20px; background: #f9f9f9; border-radius: 5px;">
                <h3>About This Widget</h3>
                <p>This AI assistant is powered by <strong>Executa.ai</strong> and provides 24/7 automated assistance to your website visitors.</p>
                <p><strong>Assistant Name:</strong> <?php echo esc_html('test bot'); ?></p>
                <p><strong>Assistant ID:</strong> <?php echo esc_html('cmc9idygx000gy93fouse1fn7'); ?></p>
                <p>To view analytics and modify your AI assistant, visit your <a href="https://app.executa.ai/dashboard" target="_blank">Executa.ai Dashboard</a>.</p>
                
                <h4>Need Help?</h4>
                <ul>
                    <li>• Check that the widget is enabled above</li>
                    <li>• Clear your browser cache if you don't see changes</li>
                    <li>• Visit <a href="https://app.executa.ai" target="_blank">Executa.ai</a> for support</li>
                </ul>
            </div>
        </div>
        <?php
    }
}

// Initialize the plugin
new ExecutaAIWidget();
?>